function exortLineChart(){
    alert("Hi");
}