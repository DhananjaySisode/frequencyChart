export class Data {
    sample : string;
    frequency : number;
}
